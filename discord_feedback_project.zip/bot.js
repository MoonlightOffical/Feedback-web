
const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');

const TOKEN = 'YOUR_BOT_TOKEN';
const FEEDBACK_API = 'https://your-vercel-app.vercel.app/api/feedback';
const STATUS_API = 'https://your-vercel-app.vercel.app/api/status';

const client = new Client({
  intents: [
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: ['CHANNEL']
});

client.on('ready', async () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  try {
    await axios.post(STATUS_API);
    console.log('🟢 Status updated to online');
  } catch (err) {
    console.error('Failed to ping status API');
  }
});

client.on('messageCreate', async (message) => {
  if (message.channel.type !== 1 || message.author.bot) return;

  try {
    await axios.post(FEEDBACK_API, {
      userId: message.author.id,
      username: message.author.tag,
      message: message.content
    });
    await message.reply("✅ Feedback received. Thanks!");
  } catch (err) {
    console.error(err);
    await message.reply("❌ Couldn't send feedback.");
  }
});

client.login(TOKEN);
