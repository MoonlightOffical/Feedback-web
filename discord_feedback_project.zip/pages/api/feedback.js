
import fs from 'fs';
import path from 'path';

const filePath = path.resolve('./data/feedback.json');

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { userId, username, message } = req.body;
    const data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
    data.push({ userId, username, message });
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    res.status(200).json({ success: true });
  } else if (req.method === 'GET') {
    const data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
    res.status(200).json(data);
  } else {
    res.status(405).end();
  }
}
