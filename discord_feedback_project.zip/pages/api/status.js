
let currentStatus = "offline";
let lastPing = null;

export default async function handler(req, res) {
  if (req.method === 'POST') {
    currentStatus = "online";
    lastPing = Date.now();
    return res.status(200).json({ success: true });
  }

  if (req.method === 'GET') {
    const now = Date.now();
    if (!lastPing || now - lastPing > 120000) {
      currentStatus = "offline";
    }
    return res.status(200).json({ status: currentStatus });
  }

  res.status(405).end();
}
