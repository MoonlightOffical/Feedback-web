
import { useEffect, useState } from 'react';
import styles from '../public/styles.module.css';

export default function Home() {
  const [feedback, setFeedback] = useState([]);
  const [status, setStatus] = useState("Loading...");

  useEffect(() => {
    fetch('/api/feedback')
      .then(res => res.json())
      .then(data => setFeedback(data));

    fetch('/api/status')
      .then(res => res.json())
      .then(data => setStatus(data.status));
  }, []);

  return (
    <div className="container">
      <h1>🤖 Bot Status: <span className={status === "online" ? "online" : "offline"}>{status}</span></h1>
      <h2>📬 User Feedback</h2>
      <ul>
        {feedback.map((fb, i) => (
          <li key={i}><strong>{fb.username}:</strong> {fb.message}</li>
        ))}
      </ul>
    </div>
  );
}
